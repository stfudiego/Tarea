To minimize score deduction, please include all of these images to your submission. Make sure image links are properly set.

Have fun with the Yellow Belt exam! :)